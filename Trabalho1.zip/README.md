# WalkingGLSpider
A simple project in openGL, where we animate and move an 2D spider to the target.
